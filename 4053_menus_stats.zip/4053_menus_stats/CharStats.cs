using UnityEngine;
using System.Collections;

public class CharStats : MonoBehaviour {
	
	//character stats
	
	public static string chname;
	public static string type; //player or enemy
	public static string className;
	public int health; 
	public static int totalHealth;
	public static Texture face;
	public int attack;
	public int speed;
	public int accuracy;
	public int specialPoints;
	public int specialDamage;
	public int defense;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	public string getName()
	{
		return chname;
	}
	public void setName(string n)
	{
		chname = n;
	}
	
	public string getType()
	{
		return type;
	}
	
	public void setType(string t)
	{
		type = t;
	}
	
	string getClass()
	{
		return className;
	}
	void setClass(string cl)
	{
		className = cl;
	}
	
	int getHealth()
	{
		return health;
	}
	void setHealth(int h)
	{
		health = h;
	}
	
	int getTotalHealth()
	{
		return totalHealth;
	}	
	void setTotalHealth(int th)
	{
		totalHealth = th;		
	}
	
	Texture getFace()
	{
		return face;
	}
	void setFace(Texture f)
	{
			face = f;
	}
	
	int getAttackPower()
	{
		return attack;
	}
	void setAttackPower(int ap)
	{
		attack = ap;
	}
	
	int getSpeed()
	{
		return speed;
	}
	void setSpeed(int sp)
	{
		speed = sp;
	}
	
	int getDefense()
	{
		return defense;
	}
	void setDefense(int d)
	{
		defense = d;
	}		
	
	int getSpecialPoints()
	{
		return specialPoints;
	}
	void setSpecialPoints(int sp)
	{
		specialPoints = sp;
	}
	
	int getSpecialDamage()
	{
		return specialDamage;
	}
	void setSpecialDamage(int sd)
	{
		specialDamage = sd;
	}
}
