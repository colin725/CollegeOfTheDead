using UnityEngine;
using System.Collections;
using UnityEditor;

public class TitleScreen : MonoBehaviour {
	
	// needs to put into Assets/Editor folder
	
	public Texture2D controlTexture;
	string username, newu = "Victor";
	bool newGame;
	bool continueGame;
	bool options;
	bool exit;
	
	
	void getMenu()
	{
				//if (Time.time % 2 < 1) {
			//if (GUI.Button (new Rect (0,0,Screen.width,Screen.height), "Meet the flashing button")) {
				//print ("You clicked me!");
			//}
		/**/
		
		//see Input page for key names
		//if(Event.key =  "escape")
		
		newGame = GUI.Button (new Rect ((Screen.width/2) - 75,0,150,50), "New Game");
		continueGame = GUI.Button (new Rect ((Screen.width/2) - 75,50,150,50), "Continue");
		options = GUI.Button (new Rect ((Screen.width/2) - 75,100,150,50), "Options");
		exit = GUI.Button (new Rect ((Screen.width/2) - 75,150,150,50), "Exit");
		
		//note: text and image:
		//  GUI.Button(new Rect(0, 0, 100, 20), new GUIContent("Click me", icon));
		
		GUI.Label (new Rect (0,0,100,50), controlTexture);
	}
	
	void OnGUI () {
		
		getMenu();
		
		if(newGame)
		{
		//check to see which button is pressed and execute
			//type in name, max length of 25
			//username = GUI.Label (new Rect((Screen.width/2) - 75,50,150,50), newu,  25);
			//username = GUI.TextField(new Rect((Screen.width/2) - 75,50,150,50), newu,  25);
			//put username in storage;
			print("username = " + username);
			//Application.LoadLevel(0);
		}
		 //*/
		else if(continueGame)
		{
			//load saved file
		}
		
		else if(options)
		{
			//load options
		}
		
		else if(exit)
		{
			GUI.Label(new Rect(0,0, Screen.width, Screen.height), "Are you sure you want to quit?");
			bool yes = GUI.Button(new Rect(0, Screen.height/2, Screen.width/2, Screen.height/2), "Yes");
			bool no = GUI.Button(new Rect(Screen.width/2, Screen.height/2, Screen.width/2, Screen.height/2), "No");
			
			if(yes)
				EditorApplication.Exit(0);
			else if(no)
				print ("not yet done");
		}		

	}
}