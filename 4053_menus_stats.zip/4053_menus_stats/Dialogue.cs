using UnityEngine;
using System.Collections;
using System.IO;

public class Dialogue : MonoBehaviour {
	
	public int dialogue = 1;
	//public static string fileName = " ";
	//public string startFrom = " ";  //Dialogue will start from a specific word in the text
	//FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
	
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		//if dialogue is running
		//if(dialogue == 1)
			GUI.Box(new Rect(0, Screen.height - 50, Screen.width, 50), "This is some dialogue that is to be used here. Will be read from a file");
	
	}
}
