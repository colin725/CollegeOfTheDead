using UnityEngine;
using System.Collections;

public class test_screen : MonoBehaviour {
	
	string chname = "test";
	//displayCharacter.setName;//(chname);
	
    void OnGUI() {
		
		//resize put at the bottom, for cutscenes and stats display
        GUI.Box(new Rect(0, 0, Screen.width, Screen.height), "This is a title");
		//GUI.Labels -> getHealth(), getName(), getClass(), getSP(), getFace(), etc.
		GUI.Label (new Rect(Screen.width - 50, Screen.height - 50, 20,20), chname);
    }
}