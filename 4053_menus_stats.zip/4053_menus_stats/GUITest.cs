// C#
using UnityEngine;
using System.Collections;

public class GUITest : MonoBehaviour {
	
	public Texture2D controlTexture;
	
	void OnGUI () {
		//if (Time.time % 2 < 1) {
			//if (GUI.Button (new Rect (0,0,Screen.width,Screen.height), "Meet the flashing button")) {
				//print ("You clicked me!");
			//}
		/**/
		
		GUI.Button (new Rect ((Screen.width/2) - 75,0,150,50), "New Game");
		GUI.Button (new Rect ((Screen.width/2) - 75,50,150,50), "Continue");
		GUI.Button (new Rect ((Screen.width/2) - 75,100,150,50), "Options");
		GUI.Button (new Rect ((Screen.width/2) - 75,150,150,50), "Exit");
		
		GUI.Label (new Rect (0,0,100,50), controlTexture);
		
		//if(GUI.Button ()
		//check to see which button is pressed and execute
		
		 //*/
		}
	}
//}