using UnityEngine;
using System.Collections;

public class StatsBox : MonoBehaviour {
	
	//CharStats Victor = new CharStats();
	//Victor.setName("Victor");
	
	string chname = "Victor";
	//CharStats.setName("Victor");
	//chname = CharStats.getName();
	//GUIStyle hoverBox = GUIStyle.hover;
	// Use this for initialization
	bool charSpace;
	
	void Start () {
	
	}
	
	void testBox()
	{
		//charSpace = GUI.Box (new Rect(Screen.width/2 - 50, 100, 50,50), "Victor", GUIStyle.onHover);
	}
	
	void OnGUI()
	{
		//if hovering over a character
		GUI.Box(new Rect(0, Screen.height - 100, Screen.width, 100), "Character stats");//, hoverBox);
		GUI.Label(new Rect(Screen.width /2, Screen.width - 75, Screen.width/2, 45), "Victor");
		GUI.Label(new Rect(Screen.width /2, Screen.width - 50, Screen.width/2, 45), "Freshman");
		GUI.Label(new Rect(0,0, Screen.width/2, Screen.height/2), "Test");
		
	}
}
