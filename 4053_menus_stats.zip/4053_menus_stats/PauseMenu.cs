using UnityEngine;
using System.Collections;
using UnityEditor;

public class PauseMenu : MonoBehaviour {
	
	bool returnToGame;
	bool stats;
	bool optionsPause;
	bool quitGame;
	
	public bool paused = false;

	/*void pauseOn()
	{
		if(paused == true)
			EditorApplication.isPaused = true;
		else
			EditorApplication.isPaused = false;
	}*/
	
	void OnGUI()
	{
		//while(EditorApplication.isPaused = true)
		if(paused == true)
		{
			//EditorApplication.isPaused = true;
			
			returnToGame = GUI.Button(new Rect ((Screen.width/2) - 75,Screen.height/2 - 75,150,50), "Return");
			stats = GUI.Button(new Rect ((Screen.width/2) - 75,Screen.height/2 - 25,150,50), "Stats");
			optionsPause = GUI.Button(new Rect ((Screen.width/2) - 75,Screen.height/2 + 25,150,50), "Options");
			quitGame = GUI.Button(new Rect ((Screen.width/2) - 75,Screen.height/2 + 75,150,50), "Quit Game");
			
			if(returnToGame)
			{
				//EditorApplication.isPaused = false;
				paused = false;
				print("returning to the game");
			}
			else if(stats)
			{
				print("checking stats");
			}
			else if(optionsPause)
			{
				print("changing some options");
			}
			else if(quitGame)
			{
				//EditorApplication.isPaused = false;
				paused = false;
				//Application.Quit();
				print("Quiting the game");
			}
		}
	}
	//if Button pressed is ' '
	//then execute what needs to be done
	
}
